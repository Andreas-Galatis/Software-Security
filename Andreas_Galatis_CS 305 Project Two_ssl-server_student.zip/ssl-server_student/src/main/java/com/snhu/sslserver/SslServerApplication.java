/* ***********************************
 * Andreas Galatis
 * CS305 Software Security
 * June 6, 2022
 * SslServerApplication.java
 * ***********************************
 */

package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";

@RestController
class ServerController{

	
	// Created function to generate Checksum
	public static String checkSum(String data) throws NoSuchAlgorithmException {
		
		// Created and initialized an object of MessageDigest class with SHA-256 algorithm cipher
		MessageDigest md = MessageDigest.getInstance("SHA-256");
		
		// Used digest() method to generate a hash value of byte type
		byte[] hash = md.digest(data.getBytes(StandardCharsets.UTF_8));
		
		// Called hexToBytes function
		String hashValue = bytesToHex(hash);
		
		return hashValue;
	}
	
	// Function to convert bytes to hexadecimal
	public static String bytesToHex(byte[] bytes) {
		StringBuilder hexString = new StringBuilder();           // stringbuilder object to hold hexString
		for (byte hashByte : bytes) {                            // for loop to parse through Byte array
			int intVal = 0xff & hashByte;
			if (intVal < 0x10) {
				hexString.append('0');
			}
			hexString.append(Integer.toHexString(intVal));       // append element into hexString
		}
		return hexString.toString();                             // return hexadecimal value
	}
	
	

	// RESTFul route to generate and return required information to web browser
    @RequestMapping("/hash")
    public String myHash() throws NoSuchAlgorithmException{
    	
    	// Inserted name in data variable
    	String data = "Andreas Galatis - Project Two Checksum";
    	
    	// Called checkSum method with data as parameter to return hash value
    	String checkSum = checkSum(data);
    	
    	// Display data, name of algorithm used, and hash value to web browser
        return "<p>data: " + data +
        		"<p>Name of Cipher Algorithm Used: SHA-256" +
        		"<p>CheckSum Value: " + checkSum;
    }
    
    
}